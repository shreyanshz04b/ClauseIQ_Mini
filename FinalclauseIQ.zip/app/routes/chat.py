from flask import Blueprint, request, jsonify
from ..services.rag import rag_pipeline

chat_bp = Blueprint("chat", __name__)

@chat_bp.post("/chat")
def chat():
    data = request.get_json(force=True)
    query = (data.get("query") or "").strip()
    if not query:
        return jsonify({"error": "Query required"}), 400

    response = rag_pipeline(query)
    
    if response['classification'] == 'NO_DOCUMENTS':
        return jsonify({
            "response": response['answer'],
            "classification": response['classification'],
            "citations": [],
            "error": response['answer']
        }), 400
    if response['classification'] == 'UNSAFE':
        return jsonify({
            "response": response['answer'],
            "classification": response['classification'],
            "citations": []
        }), 400
    return jsonify({
        "response": response['answer'],
        "classification": response['classification'],
        "citations": response.get('citations', []),
        "contexts": response.get('contexts', [])
    })
