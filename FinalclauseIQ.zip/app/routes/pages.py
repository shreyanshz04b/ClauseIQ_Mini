from flask import Blueprint, render_template, redirect, url_for

pages_bp = Blueprint("pages", __name__)


@pages_bp.get("/")
def home_page():
    return redirect(url_for("pages.landing_page"))


@pages_bp.get("/chat")
def chat_page():
    return render_template("chat.html")


@pages_bp.get("/landing")
def landing_page():
    return render_template("landing.html")
    return render_template("landing.html")
